/*
 * Copyright (c) 2015-2018, Marco Frigerio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include <cmath>
#include <iostream>
#include <fstream>

#include <sstream>
#include <string>

#include "fext.h"

#include "pronto_quadruped_commons/rbd/rbd.h"
#include "pronto_quadruped_commons/robcogen/utils.h"


namespace pronto {
namespace robcogen {
namespace test {

template<class ROB>
void cmdline_jsim(int argc, char** argv, typename ROB::JSIM& jsim)
{
    //
    typename ROB::JointState q;
    robcogen::utils::cmdlineargs_jstate<ROB>(argc-1, &(argv[1]), q);

    // a couple of "void" calls to make sure the result stays consistent
    jsim(q);
    jsim(q);
    std::cout << jsim(q) << std::endl;
}

template<class ROB>
void cmdline_jsim(int argc, char** argv)
{
    typename ROB::ForceTransforms   xf;
    typename ROB::InertiaProperties ip;
    typename ROB::JSIM              jsim(ip, xf);
    cmdline_jsim<ROB>(argc, argv, jsim);
}

}
}
}
